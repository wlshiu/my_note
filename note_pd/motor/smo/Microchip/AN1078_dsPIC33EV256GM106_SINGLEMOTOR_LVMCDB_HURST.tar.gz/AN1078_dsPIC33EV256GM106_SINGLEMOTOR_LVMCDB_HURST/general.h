/*******************************************************************************
Copyright (c) 2014 released Microchip Technology Inc. All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
*******************************************************************************/
#ifndef _GENERAL_H
#define _GENERAL_H

#ifdef __cplusplus  // Provide C++ Compatability
extern "C" {
#endif
// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************
#include <stdint.h>
#ifdef __XC16__  // See comments at the top of this header file
#include <xc.h>
#endif // __XC16__
#include <p33Exxxx.h>
#include <libq.h>
#include "user_parms.h"
#include "stdint.h"

#define FALSE  0
#define TRUE   1
#define _0_05DEG 9  /* The value for 0.05 degrees is converted */
/* to Q15 as follows: */
/* .05 * 32768 / 180 = 9.1, approx 9. */

#define Q15(Float_Value)    \
    ((Float_Value < 0.0) ? (int16_t)(32768 * (Float_Value) - 0.5) \
     : (int16_t)(32767 * (Float_Value) + 0.5))

#define REFINAMPS(Amperes_Value)    \
    (Q15((Amperes_Value)*(DQKA/32768.0)*INVA_BUS_SHUNTRES_OHM*INVA_IBUS_AMP_GAIN/(DEVICE_VDD_VOLTS/2)))

#define BTN_PRESSED         2              /*Status to indicate valid button press */
#define BTN_NOT_PRESSED     0              /*Status value indicating that button is not ptressed */
#define BTN_DEBOUNCE            1              /*Status value to indicate wating for button debounce period */

/* Main functions prototypes */
inline void DoControl(void);
inline void CalculateParkAngle(void);
void SetupControlParameters(void);
int16_t VoltRippleComp(int16_t Vdq1);


#ifdef INITIALIZE
/* allocate storage */
#define EXTERN
#else
#define EXTERN extern
#endif
#ifdef __cplusplus  // Provide C++ Compatibility
}
#endif
#endif      /* end of general_H */
