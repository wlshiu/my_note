#
# Generated Makefile - do not edit!
#
# Edit the Makefile in the project folder instead (../Makefile). Each target
# has a -pre and a -post target defined where you can add customized code.
#
# This makefile implements configuration specific macros and targets.


# Include project Makefile
ifeq "${IGNORE_LOCAL}" "TRUE"
# do not include local makefile. User is passing all local related variables already
else
include Makefile
# Include makefile containing local settings
ifeq "$(wildcard nbproject/Makefile-local-default.mk)" "nbproject/Makefile-local-default.mk"
include nbproject/Makefile-local-default.mk
endif
endif

# Environment
MKDIR=gnumkdir -p
RM=rm -f 
MV=mv 
CP=cp 

# Macros
CND_CONF=default
ifeq ($(TYPE_IMAGE), DEBUG_RUN)
IMAGE_TYPE=debug
OUTPUT_SUFFIX=elf
DEBUGGABLE_SUFFIX=elf
FINAL_IMAGE=dist/${CND_CONF}/${IMAGE_TYPE}/PMSM.X.${IMAGE_TYPE}.${OUTPUT_SUFFIX}
else
IMAGE_TYPE=production
OUTPUT_SUFFIX=hex
DEBUGGABLE_SUFFIX=elf
FINAL_IMAGE=dist/${CND_CONF}/${IMAGE_TYPE}/PMSM.X.${IMAGE_TYPE}.${OUTPUT_SUFFIX}
endif

# Object Directory
OBJECTDIR=build/${CND_CONF}/${IMAGE_TYPE}

# Distribution Directory
DISTDIR=dist/${CND_CONF}/${IMAGE_TYPE}

# Source Files Quoted if spaced
SOURCEFILES_QUOTED_IF_SPACED=../field_weak.c ../mcp802x_de2.c ../periph.c ../RTDM.c ../smcpos.c ../sys_config.c ../atan2CORDIC.s ../meas_curr.s ../read_adc0.s ../smc.s ../uart.c ../pmsm.c

# Object Files Quoted if spaced
OBJECTFILES_QUOTED_IF_SPACED=${OBJECTDIR}/_ext/1472/field_weak.o ${OBJECTDIR}/_ext/1472/mcp802x_de2.o ${OBJECTDIR}/_ext/1472/periph.o ${OBJECTDIR}/_ext/1472/RTDM.o ${OBJECTDIR}/_ext/1472/smcpos.o ${OBJECTDIR}/_ext/1472/sys_config.o ${OBJECTDIR}/_ext/1472/atan2CORDIC.o ${OBJECTDIR}/_ext/1472/meas_curr.o ${OBJECTDIR}/_ext/1472/read_adc0.o ${OBJECTDIR}/_ext/1472/smc.o ${OBJECTDIR}/_ext/1472/uart.o ${OBJECTDIR}/_ext/1472/pmsm.o
POSSIBLE_DEPFILES=${OBJECTDIR}/_ext/1472/field_weak.o.d ${OBJECTDIR}/_ext/1472/mcp802x_de2.o.d ${OBJECTDIR}/_ext/1472/periph.o.d ${OBJECTDIR}/_ext/1472/RTDM.o.d ${OBJECTDIR}/_ext/1472/smcpos.o.d ${OBJECTDIR}/_ext/1472/sys_config.o.d ${OBJECTDIR}/_ext/1472/atan2CORDIC.o.d ${OBJECTDIR}/_ext/1472/meas_curr.o.d ${OBJECTDIR}/_ext/1472/read_adc0.o.d ${OBJECTDIR}/_ext/1472/smc.o.d ${OBJECTDIR}/_ext/1472/uart.o.d ${OBJECTDIR}/_ext/1472/pmsm.o.d

# Object Files
OBJECTFILES=${OBJECTDIR}/_ext/1472/field_weak.o ${OBJECTDIR}/_ext/1472/mcp802x_de2.o ${OBJECTDIR}/_ext/1472/periph.o ${OBJECTDIR}/_ext/1472/RTDM.o ${OBJECTDIR}/_ext/1472/smcpos.o ${OBJECTDIR}/_ext/1472/sys_config.o ${OBJECTDIR}/_ext/1472/atan2CORDIC.o ${OBJECTDIR}/_ext/1472/meas_curr.o ${OBJECTDIR}/_ext/1472/read_adc0.o ${OBJECTDIR}/_ext/1472/smc.o ${OBJECTDIR}/_ext/1472/uart.o ${OBJECTDIR}/_ext/1472/pmsm.o

# Source Files
SOURCEFILES=../field_weak.c ../mcp802x_de2.c ../periph.c ../RTDM.c ../smcpos.c ../sys_config.c ../atan2CORDIC.s ../meas_curr.s ../read_adc0.s ../smc.s ../uart.c ../pmsm.c


CFLAGS=
ASFLAGS=
LDLIBSOPTIONS=

############# Tool locations ##########################################
# If you copy a project from one host to another, the path where the  #
# compiler is installed may be different.                             #
# If you open this project with MPLAB X in the new host, this         #
# makefile will be regenerated and the paths will be corrected.       #
#######################################################################
# fixDeps replaces a bunch of sed/cat/printf statements that slow down the build
FIXDEPS=fixDeps

.build-conf:  ${BUILD_SUBPROJECTS}
	${MAKE}  -f nbproject/Makefile-default.mk dist/${CND_CONF}/${IMAGE_TYPE}/PMSM.X.${IMAGE_TYPE}.${OUTPUT_SUFFIX}

MP_PROCESSOR_OPTION=33EV256GM106
MP_LINKER_FILE_OPTION=,--script=p33EV256GM106.gld
# ------------------------------------------------------------------------------------
# Rules for buildStep: compile
ifeq ($(TYPE_IMAGE), DEBUG_RUN)
${OBJECTDIR}/_ext/1472/field_weak.o: ../field_weak.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} ${OBJECTDIR}/_ext/1472 
	@${RM} ${OBJECTDIR}/_ext/1472/field_weak.o.d 
	@${RM} ${OBJECTDIR}/_ext/1472/field_weak.o 
	${MP_CC} $(MP_EXTRA_CC_PRE)  ../field_weak.c  -o ${OBJECTDIR}/_ext/1472/field_weak.o  -c -mcpu=$(MP_PROCESSOR_OPTION)  -MMD -MF "${OBJECTDIR}/_ext/1472/field_weak.o.d"      -g -D__DEBUG -D__MPLAB_DEBUGGER_REAL_ICE=1  -mno-eds-warn  -omf=elf -O0 -I".." -msmart-io=1 -msfr-warn=off -finline
	@${FIXDEPS} "${OBJECTDIR}/_ext/1472/field_weak.o.d" $(SILENT)  -rsi ${MP_CC_DIR}../ 
	
${OBJECTDIR}/_ext/1472/mcp802x_de2.o: ../mcp802x_de2.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} ${OBJECTDIR}/_ext/1472 
	@${RM} ${OBJECTDIR}/_ext/1472/mcp802x_de2.o.d 
	@${RM} ${OBJECTDIR}/_ext/1472/mcp802x_de2.o 
	${MP_CC} $(MP_EXTRA_CC_PRE)  ../mcp802x_de2.c  -o ${OBJECTDIR}/_ext/1472/mcp802x_de2.o  -c -mcpu=$(MP_PROCESSOR_OPTION)  -MMD -MF "${OBJECTDIR}/_ext/1472/mcp802x_de2.o.d"      -g -D__DEBUG -D__MPLAB_DEBUGGER_REAL_ICE=1  -mno-eds-warn  -omf=elf -O0 -I".." -msmart-io=1 -msfr-warn=off -finline
	@${FIXDEPS} "${OBJECTDIR}/_ext/1472/mcp802x_de2.o.d" $(SILENT)  -rsi ${MP_CC_DIR}../ 
	
${OBJECTDIR}/_ext/1472/periph.o: ../periph.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} ${OBJECTDIR}/_ext/1472 
	@${RM} ${OBJECTDIR}/_ext/1472/periph.o.d 
	@${RM} ${OBJECTDIR}/_ext/1472/periph.o 
	${MP_CC} $(MP_EXTRA_CC_PRE)  ../periph.c  -o ${OBJECTDIR}/_ext/1472/periph.o  -c -mcpu=$(MP_PROCESSOR_OPTION)  -MMD -MF "${OBJECTDIR}/_ext/1472/periph.o.d"      -g -D__DEBUG -D__MPLAB_DEBUGGER_REAL_ICE=1  -mno-eds-warn  -omf=elf -O0 -I".." -msmart-io=1 -msfr-warn=off -finline
	@${FIXDEPS} "${OBJECTDIR}/_ext/1472/periph.o.d" $(SILENT)  -rsi ${MP_CC_DIR}../ 
	
${OBJECTDIR}/_ext/1472/RTDM.o: ../RTDM.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} ${OBJECTDIR}/_ext/1472 
	@${RM} ${OBJECTDIR}/_ext/1472/RTDM.o.d 
	@${RM} ${OBJECTDIR}/_ext/1472/RTDM.o 
	${MP_CC} $(MP_EXTRA_CC_PRE)  ../RTDM.c  -o ${OBJECTDIR}/_ext/1472/RTDM.o  -c -mcpu=$(MP_PROCESSOR_OPTION)  -MMD -MF "${OBJECTDIR}/_ext/1472/RTDM.o.d"      -g -D__DEBUG -D__MPLAB_DEBUGGER_REAL_ICE=1  -mno-eds-warn  -omf=elf -O0 -I".." -msmart-io=1 -msfr-warn=off -finline
	@${FIXDEPS} "${OBJECTDIR}/_ext/1472/RTDM.o.d" $(SILENT)  -rsi ${MP_CC_DIR}../ 
	
${OBJECTDIR}/_ext/1472/smcpos.o: ../smcpos.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} ${OBJECTDIR}/_ext/1472 
	@${RM} ${OBJECTDIR}/_ext/1472/smcpos.o.d 
	@${RM} ${OBJECTDIR}/_ext/1472/smcpos.o 
	${MP_CC} $(MP_EXTRA_CC_PRE)  ../smcpos.c  -o ${OBJECTDIR}/_ext/1472/smcpos.o  -c -mcpu=$(MP_PROCESSOR_OPTION)  -MMD -MF "${OBJECTDIR}/_ext/1472/smcpos.o.d"      -g -D__DEBUG -D__MPLAB_DEBUGGER_REAL_ICE=1  -mno-eds-warn  -omf=elf -O0 -I".." -msmart-io=1 -msfr-warn=off -finline
	@${FIXDEPS} "${OBJECTDIR}/_ext/1472/smcpos.o.d" $(SILENT)  -rsi ${MP_CC_DIR}../ 
	
${OBJECTDIR}/_ext/1472/sys_config.o: ../sys_config.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} ${OBJECTDIR}/_ext/1472 
	@${RM} ${OBJECTDIR}/_ext/1472/sys_config.o.d 
	@${RM} ${OBJECTDIR}/_ext/1472/sys_config.o 
	${MP_CC} $(MP_EXTRA_CC_PRE)  ../sys_config.c  -o ${OBJECTDIR}/_ext/1472/sys_config.o  -c -mcpu=$(MP_PROCESSOR_OPTION)  -MMD -MF "${OBJECTDIR}/_ext/1472/sys_config.o.d"      -g -D__DEBUG -D__MPLAB_DEBUGGER_REAL_ICE=1  -mno-eds-warn  -omf=elf -O0 -I".." -msmart-io=1 -msfr-warn=off -finline
	@${FIXDEPS} "${OBJECTDIR}/_ext/1472/sys_config.o.d" $(SILENT)  -rsi ${MP_CC_DIR}../ 
	
${OBJECTDIR}/_ext/1472/uart.o: ../uart.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} ${OBJECTDIR}/_ext/1472 
	@${RM} ${OBJECTDIR}/_ext/1472/uart.o.d 
	@${RM} ${OBJECTDIR}/_ext/1472/uart.o 
	${MP_CC} $(MP_EXTRA_CC_PRE)  ../uart.c  -o ${OBJECTDIR}/_ext/1472/uart.o  -c -mcpu=$(MP_PROCESSOR_OPTION)  -MMD -MF "${OBJECTDIR}/_ext/1472/uart.o.d"      -g -D__DEBUG -D__MPLAB_DEBUGGER_REAL_ICE=1  -mno-eds-warn  -omf=elf -O0 -I".." -msmart-io=1 -msfr-warn=off -finline
	@${FIXDEPS} "${OBJECTDIR}/_ext/1472/uart.o.d" $(SILENT)  -rsi ${MP_CC_DIR}../ 
	
${OBJECTDIR}/_ext/1472/pmsm.o: ../pmsm.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} ${OBJECTDIR}/_ext/1472 
	@${RM} ${OBJECTDIR}/_ext/1472/pmsm.o.d 
	@${RM} ${OBJECTDIR}/_ext/1472/pmsm.o 
	${MP_CC} $(MP_EXTRA_CC_PRE)  ../pmsm.c  -o ${OBJECTDIR}/_ext/1472/pmsm.o  -c -mcpu=$(MP_PROCESSOR_OPTION)  -MMD -MF "${OBJECTDIR}/_ext/1472/pmsm.o.d"      -g -D__DEBUG -D__MPLAB_DEBUGGER_REAL_ICE=1  -mno-eds-warn  -omf=elf -O0 -I".." -msmart-io=1 -msfr-warn=off -finline
	@${FIXDEPS} "${OBJECTDIR}/_ext/1472/pmsm.o.d" $(SILENT)  -rsi ${MP_CC_DIR}../ 
	
else
${OBJECTDIR}/_ext/1472/field_weak.o: ../field_weak.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} ${OBJECTDIR}/_ext/1472 
	@${RM} ${OBJECTDIR}/_ext/1472/field_weak.o.d 
	@${RM} ${OBJECTDIR}/_ext/1472/field_weak.o 
	${MP_CC} $(MP_EXTRA_CC_PRE)  ../field_weak.c  -o ${OBJECTDIR}/_ext/1472/field_weak.o  -c -mcpu=$(MP_PROCESSOR_OPTION)  -MMD -MF "${OBJECTDIR}/_ext/1472/field_weak.o.d"      -mno-eds-warn  -g -omf=elf -O0 -I".." -msmart-io=1 -msfr-warn=off -finline
	@${FIXDEPS} "${OBJECTDIR}/_ext/1472/field_weak.o.d" $(SILENT)  -rsi ${MP_CC_DIR}../ 
	
${OBJECTDIR}/_ext/1472/mcp802x_de2.o: ../mcp802x_de2.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} ${OBJECTDIR}/_ext/1472 
	@${RM} ${OBJECTDIR}/_ext/1472/mcp802x_de2.o.d 
	@${RM} ${OBJECTDIR}/_ext/1472/mcp802x_de2.o 
	${MP_CC} $(MP_EXTRA_CC_PRE)  ../mcp802x_de2.c  -o ${OBJECTDIR}/_ext/1472/mcp802x_de2.o  -c -mcpu=$(MP_PROCESSOR_OPTION)  -MMD -MF "${OBJECTDIR}/_ext/1472/mcp802x_de2.o.d"      -mno-eds-warn  -g -omf=elf -O0 -I".." -msmart-io=1 -msfr-warn=off -finline
	@${FIXDEPS} "${OBJECTDIR}/_ext/1472/mcp802x_de2.o.d" $(SILENT)  -rsi ${MP_CC_DIR}../ 
	
${OBJECTDIR}/_ext/1472/periph.o: ../periph.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} ${OBJECTDIR}/_ext/1472 
	@${RM} ${OBJECTDIR}/_ext/1472/periph.o.d 
	@${RM} ${OBJECTDIR}/_ext/1472/periph.o 
	${MP_CC} $(MP_EXTRA_CC_PRE)  ../periph.c  -o ${OBJECTDIR}/_ext/1472/periph.o  -c -mcpu=$(MP_PROCESSOR_OPTION)  -MMD -MF "${OBJECTDIR}/_ext/1472/periph.o.d"      -mno-eds-warn  -g -omf=elf -O0 -I".." -msmart-io=1 -msfr-warn=off -finline
	@${FIXDEPS} "${OBJECTDIR}/_ext/1472/periph.o.d" $(SILENT)  -rsi ${MP_CC_DIR}../ 
	
${OBJECTDIR}/_ext/1472/RTDM.o: ../RTDM.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} ${OBJECTDIR}/_ext/1472 
	@${RM} ${OBJECTDIR}/_ext/1472/RTDM.o.d 
	@${RM} ${OBJECTDIR}/_ext/1472/RTDM.o 
	${MP_CC} $(MP_EXTRA_CC_PRE)  ../RTDM.c  -o ${OBJECTDIR}/_ext/1472/RTDM.o  -c -mcpu=$(MP_PROCESSOR_OPTION)  -MMD -MF "${OBJECTDIR}/_ext/1472/RTDM.o.d"      -mno-eds-warn  -g -omf=elf -O0 -I".." -msmart-io=1 -msfr-warn=off -finline
	@${FIXDEPS} "${OBJECTDIR}/_ext/1472/RTDM.o.d" $(SILENT)  -rsi ${MP_CC_DIR}../ 
	
${OBJECTDIR}/_ext/1472/smcpos.o: ../smcpos.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} ${OBJECTDIR}/_ext/1472 
	@${RM} ${OBJECTDIR}/_ext/1472/smcpos.o.d 
	@${RM} ${OBJECTDIR}/_ext/1472/smcpos.o 
	${MP_CC} $(MP_EXTRA_CC_PRE)  ../smcpos.c  -o ${OBJECTDIR}/_ext/1472/smcpos.o  -c -mcpu=$(MP_PROCESSOR_OPTION)  -MMD -MF "${OBJECTDIR}/_ext/1472/smcpos.o.d"      -mno-eds-warn  -g -omf=elf -O0 -I".." -msmart-io=1 -msfr-warn=off -finline
	@${FIXDEPS} "${OBJECTDIR}/_ext/1472/smcpos.o.d" $(SILENT)  -rsi ${MP_CC_DIR}../ 
	
${OBJECTDIR}/_ext/1472/sys_config.o: ../sys_config.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} ${OBJECTDIR}/_ext/1472 
	@${RM} ${OBJECTDIR}/_ext/1472/sys_config.o.d 
	@${RM} ${OBJECTDIR}/_ext/1472/sys_config.o 
	${MP_CC} $(MP_EXTRA_CC_PRE)  ../sys_config.c  -o ${OBJECTDIR}/_ext/1472/sys_config.o  -c -mcpu=$(MP_PROCESSOR_OPTION)  -MMD -MF "${OBJECTDIR}/_ext/1472/sys_config.o.d"      -mno-eds-warn  -g -omf=elf -O0 -I".." -msmart-io=1 -msfr-warn=off -finline
	@${FIXDEPS} "${OBJECTDIR}/_ext/1472/sys_config.o.d" $(SILENT)  -rsi ${MP_CC_DIR}../ 
	
${OBJECTDIR}/_ext/1472/uart.o: ../uart.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} ${OBJECTDIR}/_ext/1472 
	@${RM} ${OBJECTDIR}/_ext/1472/uart.o.d 
	@${RM} ${OBJECTDIR}/_ext/1472/uart.o 
	${MP_CC} $(MP_EXTRA_CC_PRE)  ../uart.c  -o ${OBJECTDIR}/_ext/1472/uart.o  -c -mcpu=$(MP_PROCESSOR_OPTION)  -MMD -MF "${OBJECTDIR}/_ext/1472/uart.o.d"      -mno-eds-warn  -g -omf=elf -O0 -I".." -msmart-io=1 -msfr-warn=off -finline
	@${FIXDEPS} "${OBJECTDIR}/_ext/1472/uart.o.d" $(SILENT)  -rsi ${MP_CC_DIR}../ 
	
${OBJECTDIR}/_ext/1472/pmsm.o: ../pmsm.c  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} ${OBJECTDIR}/_ext/1472 
	@${RM} ${OBJECTDIR}/_ext/1472/pmsm.o.d 
	@${RM} ${OBJECTDIR}/_ext/1472/pmsm.o 
	${MP_CC} $(MP_EXTRA_CC_PRE)  ../pmsm.c  -o ${OBJECTDIR}/_ext/1472/pmsm.o  -c -mcpu=$(MP_PROCESSOR_OPTION)  -MMD -MF "${OBJECTDIR}/_ext/1472/pmsm.o.d"      -mno-eds-warn  -g -omf=elf -O0 -I".." -msmart-io=1 -msfr-warn=off -finline
	@${FIXDEPS} "${OBJECTDIR}/_ext/1472/pmsm.o.d" $(SILENT)  -rsi ${MP_CC_DIR}../ 
	
endif

# ------------------------------------------------------------------------------------
# Rules for buildStep: assemble
ifeq ($(TYPE_IMAGE), DEBUG_RUN)
${OBJECTDIR}/_ext/1472/atan2CORDIC.o: ../atan2CORDIC.s  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} ${OBJECTDIR}/_ext/1472 
	@${RM} ${OBJECTDIR}/_ext/1472/atan2CORDIC.o.d 
	@${RM} ${OBJECTDIR}/_ext/1472/atan2CORDIC.o 
	${MP_CC} $(MP_EXTRA_AS_PRE)  ../atan2CORDIC.s  -o ${OBJECTDIR}/_ext/1472/atan2CORDIC.o  -c -mcpu=$(MP_PROCESSOR_OPTION)  -D__DEBUG -D__MPLAB_DEBUGGER_REAL_ICE=1  -omf=elf -I".." -Wa,-MD,"${OBJECTDIR}/_ext/1472/atan2CORDIC.o.d",--defsym=__MPLAB_BUILD=1,--defsym=__ICD2RAM=1,--defsym=__MPLAB_DEBUG=1,--defsym=__DEBUG=1,--defsym=__MPLAB_DEBUGGER_REAL_ICE=1,-g,--no-relax,-g$(MP_EXTRA_AS_POST)
	@${FIXDEPS} "${OBJECTDIR}/_ext/1472/atan2CORDIC.o.d"  $(SILENT)  -rsi ${MP_CC_DIR}../  
	
${OBJECTDIR}/_ext/1472/meas_curr.o: ../meas_curr.s  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} ${OBJECTDIR}/_ext/1472 
	@${RM} ${OBJECTDIR}/_ext/1472/meas_curr.o.d 
	@${RM} ${OBJECTDIR}/_ext/1472/meas_curr.o 
	${MP_CC} $(MP_EXTRA_AS_PRE)  ../meas_curr.s  -o ${OBJECTDIR}/_ext/1472/meas_curr.o  -c -mcpu=$(MP_PROCESSOR_OPTION)  -D__DEBUG -D__MPLAB_DEBUGGER_REAL_ICE=1  -omf=elf -I".." -Wa,-MD,"${OBJECTDIR}/_ext/1472/meas_curr.o.d",--defsym=__MPLAB_BUILD=1,--defsym=__ICD2RAM=1,--defsym=__MPLAB_DEBUG=1,--defsym=__DEBUG=1,--defsym=__MPLAB_DEBUGGER_REAL_ICE=1,-g,--no-relax,-g$(MP_EXTRA_AS_POST)
	@${FIXDEPS} "${OBJECTDIR}/_ext/1472/meas_curr.o.d"  $(SILENT)  -rsi ${MP_CC_DIR}../  
	
${OBJECTDIR}/_ext/1472/read_adc0.o: ../read_adc0.s  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} ${OBJECTDIR}/_ext/1472 
	@${RM} ${OBJECTDIR}/_ext/1472/read_adc0.o.d 
	@${RM} ${OBJECTDIR}/_ext/1472/read_adc0.o 
	${MP_CC} $(MP_EXTRA_AS_PRE)  ../read_adc0.s  -o ${OBJECTDIR}/_ext/1472/read_adc0.o  -c -mcpu=$(MP_PROCESSOR_OPTION)  -D__DEBUG -D__MPLAB_DEBUGGER_REAL_ICE=1  -omf=elf -I".." -Wa,-MD,"${OBJECTDIR}/_ext/1472/read_adc0.o.d",--defsym=__MPLAB_BUILD=1,--defsym=__ICD2RAM=1,--defsym=__MPLAB_DEBUG=1,--defsym=__DEBUG=1,--defsym=__MPLAB_DEBUGGER_REAL_ICE=1,-g,--no-relax,-g$(MP_EXTRA_AS_POST)
	@${FIXDEPS} "${OBJECTDIR}/_ext/1472/read_adc0.o.d"  $(SILENT)  -rsi ${MP_CC_DIR}../  
	
${OBJECTDIR}/_ext/1472/smc.o: ../smc.s  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} ${OBJECTDIR}/_ext/1472 
	@${RM} ${OBJECTDIR}/_ext/1472/smc.o.d 
	@${RM} ${OBJECTDIR}/_ext/1472/smc.o 
	${MP_CC} $(MP_EXTRA_AS_PRE)  ../smc.s  -o ${OBJECTDIR}/_ext/1472/smc.o  -c -mcpu=$(MP_PROCESSOR_OPTION)  -D__DEBUG -D__MPLAB_DEBUGGER_REAL_ICE=1  -omf=elf -I".." -Wa,-MD,"${OBJECTDIR}/_ext/1472/smc.o.d",--defsym=__MPLAB_BUILD=1,--defsym=__ICD2RAM=1,--defsym=__MPLAB_DEBUG=1,--defsym=__DEBUG=1,--defsym=__MPLAB_DEBUGGER_REAL_ICE=1,-g,--no-relax,-g$(MP_EXTRA_AS_POST)
	@${FIXDEPS} "${OBJECTDIR}/_ext/1472/smc.o.d"  $(SILENT)  -rsi ${MP_CC_DIR}../  
	
else
${OBJECTDIR}/_ext/1472/atan2CORDIC.o: ../atan2CORDIC.s  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} ${OBJECTDIR}/_ext/1472 
	@${RM} ${OBJECTDIR}/_ext/1472/atan2CORDIC.o.d 
	@${RM} ${OBJECTDIR}/_ext/1472/atan2CORDIC.o 
	${MP_CC} $(MP_EXTRA_AS_PRE)  ../atan2CORDIC.s  -o ${OBJECTDIR}/_ext/1472/atan2CORDIC.o  -c -mcpu=$(MP_PROCESSOR_OPTION)  -omf=elf -I".." -Wa,-MD,"${OBJECTDIR}/_ext/1472/atan2CORDIC.o.d",--defsym=__MPLAB_BUILD=1,-g,--no-relax,-g$(MP_EXTRA_AS_POST)
	@${FIXDEPS} "${OBJECTDIR}/_ext/1472/atan2CORDIC.o.d"  $(SILENT)  -rsi ${MP_CC_DIR}../  
	
${OBJECTDIR}/_ext/1472/meas_curr.o: ../meas_curr.s  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} ${OBJECTDIR}/_ext/1472 
	@${RM} ${OBJECTDIR}/_ext/1472/meas_curr.o.d 
	@${RM} ${OBJECTDIR}/_ext/1472/meas_curr.o 
	${MP_CC} $(MP_EXTRA_AS_PRE)  ../meas_curr.s  -o ${OBJECTDIR}/_ext/1472/meas_curr.o  -c -mcpu=$(MP_PROCESSOR_OPTION)  -omf=elf -I".." -Wa,-MD,"${OBJECTDIR}/_ext/1472/meas_curr.o.d",--defsym=__MPLAB_BUILD=1,-g,--no-relax,-g$(MP_EXTRA_AS_POST)
	@${FIXDEPS} "${OBJECTDIR}/_ext/1472/meas_curr.o.d"  $(SILENT)  -rsi ${MP_CC_DIR}../  
	
${OBJECTDIR}/_ext/1472/read_adc0.o: ../read_adc0.s  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} ${OBJECTDIR}/_ext/1472 
	@${RM} ${OBJECTDIR}/_ext/1472/read_adc0.o.d 
	@${RM} ${OBJECTDIR}/_ext/1472/read_adc0.o 
	${MP_CC} $(MP_EXTRA_AS_PRE)  ../read_adc0.s  -o ${OBJECTDIR}/_ext/1472/read_adc0.o  -c -mcpu=$(MP_PROCESSOR_OPTION)  -omf=elf -I".." -Wa,-MD,"${OBJECTDIR}/_ext/1472/read_adc0.o.d",--defsym=__MPLAB_BUILD=1,-g,--no-relax,-g$(MP_EXTRA_AS_POST)
	@${FIXDEPS} "${OBJECTDIR}/_ext/1472/read_adc0.o.d"  $(SILENT)  -rsi ${MP_CC_DIR}../  
	
${OBJECTDIR}/_ext/1472/smc.o: ../smc.s  nbproject/Makefile-${CND_CONF}.mk
	@${MKDIR} ${OBJECTDIR}/_ext/1472 
	@${RM} ${OBJECTDIR}/_ext/1472/smc.o.d 
	@${RM} ${OBJECTDIR}/_ext/1472/smc.o 
	${MP_CC} $(MP_EXTRA_AS_PRE)  ../smc.s  -o ${OBJECTDIR}/_ext/1472/smc.o  -c -mcpu=$(MP_PROCESSOR_OPTION)  -omf=elf -I".." -Wa,-MD,"${OBJECTDIR}/_ext/1472/smc.o.d",--defsym=__MPLAB_BUILD=1,-g,--no-relax,-g$(MP_EXTRA_AS_POST)
	@${FIXDEPS} "${OBJECTDIR}/_ext/1472/smc.o.d"  $(SILENT)  -rsi ${MP_CC_DIR}../  
	
endif

# ------------------------------------------------------------------------------------
# Rules for buildStep: assemblePreproc
ifeq ($(TYPE_IMAGE), DEBUG_RUN)
else
endif

# ------------------------------------------------------------------------------------
# Rules for buildStep: link
ifeq ($(TYPE_IMAGE), DEBUG_RUN)
dist/${CND_CONF}/${IMAGE_TYPE}/PMSM.X.${IMAGE_TYPE}.${OUTPUT_SUFFIX}: ${OBJECTFILES}  nbproject/Makefile-${CND_CONF}.mk  ../lib/libmotor_control_dspic33e-elf.a  
	@${MKDIR} dist/${CND_CONF}/${IMAGE_TYPE} 
	${MP_CC} $(MP_EXTRA_LD_PRE)  -o dist/${CND_CONF}/${IMAGE_TYPE}/PMSM.X.${IMAGE_TYPE}.${OUTPUT_SUFFIX}  ${OBJECTFILES_QUOTED_IF_SPACED}    ..\lib\libmotor_control_dspic33e-elf.a  -mcpu=$(MP_PROCESSOR_OPTION)        -D__DEBUG -D__MPLAB_DEBUGGER_REAL_ICE=1  -omf=elf -Wl,--local-stack,--defsym=__MPLAB_BUILD=1,--defsym=__ICD2RAM=1,--defsym=__MPLAB_DEBUG=1,--defsym=__DEBUG=1,--defsym=__MPLAB_DEBUGGER_REAL_ICE=1,$(MP_LINKER_FILE_OPTION),--check-sections,--data-init,--pack-data,--handles,--isr,--no-gc-sections,--fill-upper=0,--stackguard=16,--library=q,--library-path="..",--no-force-link,--smart-io,--report-mem$(MP_EXTRA_LD_POST) 
	
else
dist/${CND_CONF}/${IMAGE_TYPE}/PMSM.X.${IMAGE_TYPE}.${OUTPUT_SUFFIX}: ${OBJECTFILES}  nbproject/Makefile-${CND_CONF}.mk  ../lib/libmotor_control_dspic33e-elf.a 
	@${MKDIR} dist/${CND_CONF}/${IMAGE_TYPE} 
	${MP_CC} $(MP_EXTRA_LD_PRE)  -o dist/${CND_CONF}/${IMAGE_TYPE}/PMSM.X.${IMAGE_TYPE}.${DEBUGGABLE_SUFFIX}  ${OBJECTFILES_QUOTED_IF_SPACED}    ..\lib\libmotor_control_dspic33e-elf.a  -mcpu=$(MP_PROCESSOR_OPTION)        -omf=elf -Wl,--local-stack,--defsym=__MPLAB_BUILD=1,$(MP_LINKER_FILE_OPTION),--check-sections,--data-init,--pack-data,--handles,--isr,--no-gc-sections,--fill-upper=0,--stackguard=16,--library=q,--library-path="..",--no-force-link,--smart-io,--report-mem$(MP_EXTRA_LD_POST) 
	${MP_CC_DIR}\\xc16-bin2hex dist/${CND_CONF}/${IMAGE_TYPE}/PMSM.X.${IMAGE_TYPE}.${DEBUGGABLE_SUFFIX} -a  -omf=elf  
	
endif


# Subprojects
.build-subprojects:


# Subprojects
.clean-subprojects:

# Clean Targets
.clean-conf: ${CLEAN_SUBPROJECTS}
	${RM} -r build/default
	${RM} -r dist/default

# Enable dependency checking
.dep.inc: .depcheck-impl

DEPFILES=$(shell mplabwildcard ${POSSIBLE_DEPFILES})
ifneq (${DEPFILES},)
include ${DEPFILES}
endif
