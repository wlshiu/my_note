;*********************************************************************************
; Copyright (c) 2014 released Microchip Technology Inc.  All rights reserved.
; Microchip licenses to you the right to use, modify, copy and distribute
; Software only when embedded on a Microchip microcontroller or digital signal
; controller that is integrated into your product or third party product
; (pursuant to the sublicense terms in the accompanying license agreement).
;
; You should refer to the license agreement accompanying this Software for
; additional information regarding your rights and obligations.
;
; SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
; EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
; MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
; IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
; CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
; OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
; INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
; CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
; SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
; (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
;*********************************************************************************
; ReadSignedADC0
;
;Description:
;  Read Channel 0 of ADC, scale it using qK and put results in qADValue.
;  Do not call this routine until conversion is completed.
;
;  ReadSignedADC0 range is qK*(-1.0 ->0.9999).
;
;  Scaling constant, qK, must be set elsewhere such that
;         iResult = qK * ADCBUF0
;
;Functional prototype:
;
; void ReadSignedADC0( tReadADCParm* pParm ) : Calculates signed value qK -> qK
;
;On Entry:   ReadADCParm structure must contain qK. ADC channel 0
;            must contain signed fractional value.
;
;On Exit:    ReadADCParm will contain qADValue
;
;Parameters:
; Input arguments: None
;
; Return:
;   Void
;
; SFR Settings required:
;         CORCON.SATA  = 0
;     If there is any chance that Accumulator will overflow must set
;         CORCON.SATDW = 1
;
; Support routines required: None
;
; Local Stack usage: None
;
; Registers modified: w0,w4,w5
;
;
;*******************************************************************************

          .include "general.inc"

; External references
          .include "read_adc.inc"

; Register usage
          .equ Input,w0      ; ADC Buffer Register
          .equ ParmBaseW,w1  ; Base of parm structure
          .equ Work0W,   w4
          .equ Work1W,   w5


;=================== CODE =====================

          .section  .text

          .global   _ReadSignedADC0
          .global   ReadSignedADC0

_ReadSignedADC0:
ReadSignedADC0:

     ;; iResult = qK * ADCBUF0

		  mov.w     [ParmBaseW+ADC_qK],Work0W
          mov.w		Input, Work1W

          mpy       Work0W*Work1W,A
          sac       A,#0,Work0W
          mov.w     Work0W,[ParmBaseW+ADC_qADValue]

          return

          .global   _ReadADC0_VDC
          .global   ReadADC0_VDC
_ReadADC0_VDC:
ReadADC0_VDC:

		; Read DC Bus, remove sign
		mov.w	Input, Work0W
		asr.w 	Work0W, Work1W
  		mov.w	#0x4000, Work0W
		add.w	Work1W, Work0W, Work0W
		mov.w	Work0W, [ParmBaseW]

		return

        .end
