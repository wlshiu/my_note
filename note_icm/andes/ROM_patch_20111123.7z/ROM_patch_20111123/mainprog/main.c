/*
 * main.c
 *
 *  Created on: 2011/11/17
 *      Author: Cindy
 */

#include <stdio.h>
#include <stdlib.h>
int mul2(int);
int mul3(int);
int mul4(int);
int num2=2;
int num3=3;
int num4=4;

typedef struct strfunptr {
   int (*func_a)(int);
   int (*func_b)(int);
   int (*func_c)(int);
}sfptr;

sfptr jump_table __attribute__ ((section ("FUNC_TABLE")))= {mul2, mul3, mul4};

int main(void) {

	printf("mul2(30)=%d\n",jump_table.func_a(30));
	printf("mul3(30)=%d\n",jump_table.func_b(30));
	printf("mul4(30)=%d\n",jump_table.func_c(30));

	return EXIT_SUCCESS;
}

int mul2(int x){
	return x*num2;
}
int mul3(int x){
	return x*num3;
}
int mul4(int x){
	return x*num4;
}
