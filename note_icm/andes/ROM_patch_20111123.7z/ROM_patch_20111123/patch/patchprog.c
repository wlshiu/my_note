/*
 * patchprog.c
 *
 *  Created on: 2011/11/21
 *      Author: hylai
 */
#include <stdio.h>
#include <stdlib.h>

extern int mul3(int) ;
extern int mul4(int);
int mul2(int) __attribute__ ((section ("FUNC_PATCH")));
extern int num2;

typedef struct strfunptr {
   int (*func_a)(int);
   int (*func_b)(int);
   int (*func_c)(int);
}sfptr;

sfptr jump_table __attribute__ ((section ("FUNC_TABLE")))= {mul2, mul3, mul4};

int mul2(int x){
	return x*num2*100;
}

