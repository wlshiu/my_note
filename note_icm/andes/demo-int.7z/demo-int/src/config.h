/* lowlevel platform initialization if no bootcode.
 * Don't do this if there is bootcode on the platform, 
 * let bootcode do the work.*/
#define BURN		0 	/* burn = 1, load = 0 */
//#define USE_LM_DMA
#define CONFIG_AG101P_16MB 	/* In 16MB board*/
//#define AG101         1 /* For AG101 board, else for XC5 board */
