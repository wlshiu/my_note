# bounds_checking_function

#### 介绍
- 遵循C11 Annex K (Bounds-checking interfaces)的标准，选取并实现了常见的内存/字符串操作类的函数，如memcpy_s、strcpy_s等函数。
- 未来将分析C11 Annex K中的其他标准函数，如果有必要，将在该组织中实现。
- 处理边界检查函数的版本发布、更新以及维护。
