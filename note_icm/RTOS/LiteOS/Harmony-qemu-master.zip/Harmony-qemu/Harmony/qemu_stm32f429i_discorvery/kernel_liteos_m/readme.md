详见：https://gitee.com/openharmony/docs/blob/master/readme/内核子系统README.md

see: https://gitee.com/openharmony/docs/blob/master/docs-en/readme/kernel-subsystem.md
